from rest_framework import serializers
from .models import CountryFile
from .models import StateFile
from .models import CityFile





class CountryFileUploadSerializer(serializers.Serializer):
    
    country_name = serializers.CharField(max_length=255)
    country_code= serializers.CharField(required=False, allow_blank=True)

    def create(self, validated_data):
        country_name = validated_data['country_name']
        country_code= validated_data['country_code']
        created_by = self.context['request'].user
        

       

        # Save the metadata to the database
        country_file = CountryFile.objects.create(
            country_name=country_name,
            country_code=country_code,
            created_by=created_by 
        )
        return country_file
    
    
class StateFileUploadSerializer(serializers.Serializer):
    
        class Meta:
           model =StateFile
           fields = ['id', 'state_name', 'country_id']
        

       

      
    
class CityFileUploadSerializer(serializers.Serializer):
     city_name=serializers.CharField(max_length=255)
     postal_code= serializers.CharField(max_length=10)
     country_id=serializers.IntegerField(write_only=True)
     state_id=serializers.IntegerField(write_only=True)

     def create(self, validated_data):
        city_name = validated_data['city_name']
        postal_code = validated_data['postal_code']
        state= StateFile.objects.get(id=validated_data['state_id'])
        country= CountryFile.objects.get(id=validated_data['country_id'])
        created_by = self.context['request'].user
        

       

        # Save the metadata to the database
        city_file = CityFile.objects.create(
            city_name=city_name,
            postal_code=postal_code,
            country_id=country_id,
            state_id=state_id,
            created_by=created_by 
        )
        return city_file
    