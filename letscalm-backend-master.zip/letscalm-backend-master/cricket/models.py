from django.db import models
from django.conf import settings
# Create your models here.
class CountryFile(models.Model):
    country_name=models.CharField(max_length=100,unique=True)
    country_code=models.CharField(max_length=10,unique=True)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return self.country_name
      
   

class StateFile(models.Model):
    state_name=models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    country_id=models.ForeignKey(CountryFile, on_delete=models.CASCADE)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together=('state_name','country_id')
     
    def __str__(self):
        return f"{self.State_name},{self.country.country_name}"

class CityFile(models.Model):
    city_name=models.CharField(max_length=100)
    postal_code=models.CharField(max_length=10,blank=True,null=True)
    is_active = models.BooleanField(default=True)
    country_id=models.ForeignKey(CountryFile, on_delete=models.CASCADE)
    state_id=models.ForeignKey(StateFile, on_delete=models.CASCADE)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        unique_together=('city_name','state_id','country_id')
     
    def __str__(self):
            return f"{self.city_name},{self.state.state_name},{self.country.country_name}"
        
        
        