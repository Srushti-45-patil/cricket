from django.urls import path
from .views import CountryFileUploadView,StateFileUploadView,CityFileUploadView

urlpatterns = [

    path('upload-data/', CountryFileUploadView.as_view(), name='upload-data'),
    path('upload-state-data/', StateFileUploadView.as_view(), name='upload-state-data'),
    path('upload-city-data/',CityFileUploadView.as_view(),name='upload-city-data')
]
