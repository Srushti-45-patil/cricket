
from rest_framework import status
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from .serializers import CountryFileUploadSerializer,StateFileUploadSerializer,CityFileUploadSerializer
from django.shortcuts import get_object_or_404

from django.db.models import Q
import requests
from django.http import StreamingHttpResponse
from rest_framework import status, permissions
import os

import speech_recognition as sr
from django.core.files.storage import default_storage


from django.shortcuts import render
class CountryFileUploadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        serializer = CountryFileUploadSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            country_file = serializer.save()  # The file is uploaded and metadata is saved here
            return Response({
                'msg': 'Country Data uploaded successfully',
                'data': {
                    'country_name': country_file.country_name,
                    'country_code': country_file.country_code,
                    
                 }
            }, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    

class StateFileUploadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = StateFileUploadSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
class CityFileUploadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, *args, **kwargs):
        serializer = CityFileUploadSerializer(data=request.data, context={'request': request})

        if serializer.is_valid():
            city_file = serializer.save()  # The file is uploaded and metadata is saved here
            return Response({
                'msg': 'City Data uploaded successfully',
                'data': {
                    'city_name': city_file.city_name,
                    'postal_code': city_file.postal_code,
                    'country_id': city_file.country_id,
                    'state_id': city_file.state_id,
                    
                 }
            }, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)